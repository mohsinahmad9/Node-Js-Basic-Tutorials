const fs = require('fs')
const data = 'This is Vivek Chauhan, I am learning Node.JS';
fs.writeFile('asyncRead.txt',data, err=>{
    if(err)
    {
        throw err;
    }
})
// fs.readFile('asyncRead.txt','utf-8', (err,data)=>{
//     if(!err)
//     {
//         console.log(data)
//     }
//     else{
//         throw err;
//     }
// });

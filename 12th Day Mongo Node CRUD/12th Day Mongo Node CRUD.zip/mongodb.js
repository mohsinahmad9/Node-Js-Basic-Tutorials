const {MongoClient} = require('mongodb');
const url = 'mongodb://0.0.0.0:27017';
const client = new MongoClient(url);


async function dbConnet()
{
    let result = await client.connect();
    db = result.db('e-comm');
    return db.collection('product');
}

module.exports = dbConnet;